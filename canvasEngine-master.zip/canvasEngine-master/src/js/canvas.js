window.onload = function() {
    Engine.start('myCanvas',30,400,640)
    laserAn = getScreen(0,100)
    DrawBoard.add(laserAn)
    Action.createNew('play',laserAn,99999999)
    // var agent_attackArr = []
    // for (let index = 1; index < 7; index++) {
    //     var src = 'agent/agent_attack_' + index +'.png';
    //     var sp = Spirit.createNewSplit(src,100,100,1,0,0,64,64)
    //     agent_attackArr.push(sp)
    // }
    // var agent_attack = Animation.createNew(agent_attackArr,1,40,0)
    // DrawBoard.add(agent_attack)
    // Action.createNew('play',agent_attack,1)
    // Action.createNew('play',agent_attack,1)
    // Action.createNew('play',agent_attack,1)

    // var agent_shotArr = []
    // for (let index = 1; index < 3; index++) {
    //     var src = 'agent/agent_shot_fx_' + index +'.png';
    //     var sp = Spirit.createNewSplit(src,100,100,1,0,0,64,64)
    //     agent_shotArr.push(sp)
    // }
    // var agent_shot = Animation.createNew(agent_shotArr, 0.4,0,0)
    // DrawBoard.add(agent_shot)
    // Action.createNew('disappear',agent_shot,0.6)
    // Action.createNew('play',agent_shot,0.4)
    // Action.createNew('disappear',agent_shot,0.6)
    // Action.createNew('play',agent_shot,0.4)
    // Action.createNew('disappear',agent_shot,0.6)
    // Action.createNew('play',agent_shot,0.4)
    // Action.createNew('disappear',agent_shot,0.4)
    
}


function getLaserTrap(x,y){
    var laserArr = []
    laserArr.push(Spirit.createNewSplit('others/laser_trap_big_h_off.png',0,0,1,0,0,256,16))
    for (let index = 1; index < 5; index++) {
        var src = 'others/laser_trap_h_big_' + index +'.png';
        var sp = Spirit.createNewSplit(src,0,0,1,0,0,256,16)
        laserArr.push(sp)
    }
    return Animation.createNew(laserArr, 1,x,y)
}

function getScreen(x,y){
    var Arr = []
    for (let index = 1; index < 9; index++) {
        var src = 'screen/screen_blood_' + index +'.png';
        var sp = Spirit.createNewSplit(src,0,0,1.5,0,0,240,190)
        Arr.push(sp)
    }
    return Animation.createNew(Arr, 1.6,x,y)
}


var DrawBoard = {
    spiritArr:[], //spirit数组
    ctx:null,
    width:0,
    height:0,
    init:function(canvasId, width=0, height=0){ 
        var c = document.getElementById(canvasId)
        this.ctx = c.getContext("2d")
        if(width == 0 || height == 0){
            c.width = window.screen.width
            c.height = window.screen.height
        }
        else{
            c.width = width
            c.height = height
        }
        this.width = c.width
        this.height = c.height
    },
    add:function(spirit){
        this.spiritArr.push(spirit)
    },
    drawSpirit:function(spirit){
        this.ctx.drawImage(spirit.img, spirit.sx, spirit.sy, spirit.swidth, 
            spirit.sheight, spirit.x, spirit.y, spirit.width, spirit.height)
    },
    draw:function(){
        this.ctx.clearRect(0, 0, this.width, this.height)   
        this.spiritArr.forEach(spirit => {
            spirit.putOn()
        });
    }
}



var Spirit = {
    createNewSplit:function(src='', x=0, y=0, scale=1, sx=0, sy=0, swidth=0, sheight=0){
        var spirit = {
        }
        var oImg= new Image();
        oImg.src = 'src/img/'+src;
        spirit.img = oImg; //src 为图片  名字.后缀
        spirit.x = x
        spirit.y = y
        spirit.sx = sx
        spirit.sy = sy
        spirit.swidth = swidth
        spirit.sheight = sheight
        spirit.scale = scale //缩放比例
        spirit.width = spirit.swidth*scale //精灵大小：宽
        spirit.height = spirit.sheight*scale //精灵大小：长
        spirit.mode = 's' //s = split 剪切下来的精灵
        spirit.putOn = function(){  //把精灵放进画板
            DrawBoard.drawSpirit(spirit)
        }
        return spirit
    },
}

var Animation = {
    createNew:function(spititArr, delay = 1, x = null, y = null){
        var index = 0
        var an = {}
        var arr = spititArr
        var anDelayTime = delay //整个动画运行时间(s)
        var actionArr = [] //动作运行列表[action]
        var runFrame = 0  //已经运行的帧数
        var visible = false //默认可视(true)  不可视 (false)
        an.x = x
        an.y = y
        if(x == null){
            an.x = spititArr[0].x
            an.y = spititArr[0].y
        }
        an.nextFrame = function(){ //根据action设置该an的下一帧
            runFrame++
            var nextIndex = parseInt(runFrame/parseInt(Engine.fps*anDelayTime/arr.length))
            if(nextIndex == arr.length){ //动画播到最后一个，重头开始
                nextIndex = 0
                runFrame = 0
            }
            
            if(actionArr.length > 0){ //action动作存在
               
                var act = actionArr[0]
                var next = act.getNext()
                console.log(next)
                if(next == null){
                    actionArr.splice(0,1)
                    an.nextFrame()
                }
                else{
                    
                    if(next.mode == 'move'){
                        
                        visible = true
                        arr[nextIndex].x = an.x + next.x
                        arr[nextIndex].y = an.y + next.y
                        an.x = arr[nextIndex].x
                        an.y = arr[nextIndex].y
                        index = nextIndex
                    }
                    if(next.mode == 'pause'){
                        index = index
                        visible = true
                    }
                    if(next.mode == 'disappear'){
                        visible = false
                    }
                    if(next.mode == 'play'){
                        index = nextIndex
                        visible = true
                    }
                }
            }
            else{
                index = index
            }
        }
        //动画运行多少时间
        an.delay = function(delayTime){
            anDelayTime = delayTime
        }
        //移动到某个地点及用时
        an.addAction = function(action){
           actionArr.push(action)
        }
        an.putOn = function(){
            arr[index].x = an.x
            arr[index].y = an.y
            if(visible == true){
                DrawBoard.drawSpirit(arr[index])  
            }
            an.nextFrame()
            
        }
        return an
    }
}

var Action = {
    createNew:function(mode='', aspirit=null, delay=1, x=0, y=0){
        var action = {}
        var ax = x  //目标地点
        var ay = y
        if(mode == 'moveBy'){ //转相对移动为绝对移动
            ax = x + aspirit.x
            ay = y + aspirit.y
        }
        var delayTime = delay
        var amode = mode //行为模式 move pause
        var spirit = aspirit
        var moveByX = parseInt((ax-spirit.x)/(delayTime*Engine.fps))
        var moveByY = parseInt((ay-spirit.y)/(delayTime*Engine.fps))
        var frames = 0 //已经运行的帧数
        
        //获得行为下一步数据return {mode:modename,......}
        action.getNext = function(){
            if(amode == 'moveTo' || amode == 'moveBy'){ //移动到某个点，绝对移动
                if(frames >= delayTime*Engine.fps){
                    frames = 0
                    return null
                }
                else{
                    frames++
                    return {'mode':'move', 'x':moveByX,
                            'y':moveByY,'frames':frames}
                }
            }
            if(amode == 'pause' || amode == 'disappear' || amode == 'play'){ //暂停
                if(frames >= delayTime*Engine.fps){
                    frames = 0
                    return null
                }
                else{
                    frames++
                    return {'mode':amode,'frames':frames}
                }
            }
        }
        spirit.addAction(action)
        return action
    }
}

var Engine = {
    plan:[],
    fps:30,
    intvalId:0,
    canvasId:'',
    start:function(canvasId, fps = 30,width,height){
        DrawBoard.init(canvasId,width,height)
        this.canvasId = canvasId
        this.fps = fps
        this.intvalId = setInterval(function(){
            DrawBoard.draw()
        },parseInt(1000/fps))
    },
    stop:function(){
        clearInterval(this.intvalId)
    },
    doContinue:function(){
        this.intvalId = setInterval(function(){
            DrawBoard.draw()
        },parseInt(1000/fps))
    }    
}
var myEvent = {
    addEvent:function(domId='',eventName='',func=function(){}){
        document.getElementById(domId).addEventListener(eventName,func)
    }
}
