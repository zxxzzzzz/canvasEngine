window.onload = function() {
    Engine.start('myCanvas',30)
    Mangent.init()
    Mangent.add(myFile.createNew(0,0,'1个文件'))
    Mangent.add(Folder.createNew(0,0,'2文件夹'))
    Mangent.add(Folder.createNew(0,0,'一3个文件夹'))
    Mangent.add(myFile.createNew(0,0,'一4个文件'))
    Mangent.add(myFile.createNew(0,0,'一5个文件'))
    Mangent.add(Folder.createNew(0,0,'一6个文件夹'))
    Mangent.add(Folder.createNew(0,0,'一7个文件夹'))
    Mangent.add(myFile.createNew(0,0,'一8个文件'))
    Mangent.add(myFile.createNew(0,0,'一9个文件'))
    Mangent.add(Folder.createNew(0,0,'一10个文件夹'))
    Mangent.add(Folder.createNew(0,0,'一11个文件夹'))
    Mangent.add(myFile.createNew(0,0,'一12个文件'))
    Mangent.add(myFile.createNew(0,0,'一13个文件'))
    Mangent.add(Folder.createNew(0,0,'一个14文件夹'))
    Mangent.add(Folder.createNew(0,0,'一15个文件夹'))
    Mangent.add(myFile.createNew(0,0,'一16个文件'))
    Mangent.add(myFile.createNew(0,0,'一17个文件'))
    Mangent.add(Folder.createNew(0,0,'一18个文件夹'))
    Mangent.add(Folder.createNew(0,0,'一19个文件夹'))
    Mangent.add(myFile.createNew(0,0,'一20个文件'))
    Mangent.add(myFile.createNew(0,0,'一21个文件'))
    // var f1 = Folder.createNew(0,0,'一个文件夹')
    // f1.putOn()
    // var f2 = Folder.createNew(128,0,'第二个文件夹第二个文件夹')
    // f2.putOn()
    // myEventListener.add(f1,function(){
    //     // f1.changeImg('focus')
    //     // f2.changeImg('unfocus')
    //     // console.log(f1)
    //     DrawBoard.clear()
    //     var fi1 = File.createNew(0,0,'一个文件')
    //     fi1.putOn()
    //     var fi2 = File.createNew(128,0,'di二个文件')
    //     fi2.putOn()
    // },'dblclick')
    // myEventListener.add(f2,function(){
    //     f1.changeImg('unfocus')
    //     f2.changeImg('focus')
    //     console.log(f2)
    // })
    
}

//文件夹 文件管理器
/**
 * 自动排列(文件夹 文件)
 * 自动添加click菜单
 * 自动给文件夹添加dblclick进入事件
 */
var Mangent = {
    init:function(){
        Mangent.arr = []
        Mangent.lineMax = 10  //行最大放置数
        Mangent.columnLeading = 128 //列间距
    },
    add:function(folder){
        myEventListener.add(folder,function(e){
            console.log(folder)
            Mangent.focus(folder)
        },'click')
        myEventListener.add(folder,function(e){
            console.log(folder.x)
        },'dblclick')
        myEventListener.add(folder,function(e){
            Mangent.showDetail(folder)
        },'rclick')
        Mangent.arr.push(folder)
        Mangent.typeset()
        folder.putOn()
    },
    //单击focus 文件夹 文件 出现选中状态 显示详细信息
    focus:function(faf){
        Mangent.arr.forEach(elem => {
            if(elem.state == 'focus'){
                elem.state = 'unfocus'
                elem.changeImg()
            }
        });
        faf.state = 'focus'
        faf.changeImg()
        //console.log(folder.state)
    },
    //右击事件
    showDetail:function(){
        alert('some detail')
    },
    //排版
    typeset:function(){
        //var iMax = parseInt(DrawBoard.width/Mangent.arr[0].getFolderAn().width) - 1
        var xdistance = parseInt(DrawBoard.width/Mangent.lineMax)
        //console.log(Mangent.arr[0].getFolderAn().width)
        var i = 0 //行
        var j = 0 //列
        Mangent.arr.forEach(elem => {
            if(i > Mangent.lineMax -1){
                j++
                i=0
            }
            if(elem.type == 'folder'){
                elem.setPosition(i*xdistance, j*Mangent.columnLeading)
            }
            if(elem.type == 'file'){
                elem.setPosition(i*xdistance, j*Mangent.columnLeading)
            }
            i++
        });
    },
    

}
/**
 * 规范folder类，不可提前配置位置
 * 位置要保持一致
 */
var Folder = {
    createNew:function(x = 0,y = 0,fname = '',src='folder/folder.png'){
        var name = fname  //文件夹名字
        if(name.length >7){ //最多8个字符（没考虑中英文）
            name = name.slice(0,7) + '...'
        }
        var folderAn = Animation.createNew([Spirit.createNewSplit(src,0,0,1,0,0,128,128)],1,x,y)
        var folder = {}
        folder.picX = x //图片的位置(图片总有透明处，实际比显示的物体大)
        folder.picY = y
        folder.state = 'unfocus'
        folder.type = 'folder'
        folder.x = x + 16 //物体位置
        folder.y = y + 25
        folder.width = 96 //物体长
        folder.height = 70
        folder.putOn = function(){
            folder.changeImg()
            DrawBoard.add(folderAn)
            DrawBoard.add(Text.createNew(name, folderAn.x+10, folderAn.y+128,'italic small-caps bold 12px arial'))
            Action.createNew('play',folderAn,0.1)
        }
        folder.disAppear = function(){
            Action.createNew('disappear',folderAn,0.1)
        }
        folder.getFolderAn = function(){
            return folderAn
        }
        folder.getName = function(){
            return name
        }
        //改变图片位置
        folder.setPosition = function(x,y){
            //console.log(x,y)
            folder.picX = x
            folder.picY = y
            folder.x = x + 16 //物体位置
            folder.y = y + 25
            folderAn.setPosition(x,y)
        }
        //改变显示的图片 默认使用自己状态
        folder.changeImg = function(mode = ''){
            //console.log(mode)
            if(mode == ''){
                mode = folder.state
            }
            if(mode == 'focus'){
                folderAn.getSpiritArr()[0].changeImg('folder/folder_focus.png')
            }
            if(mode == 'unfocus'){
                folderAn.getSpiritArr()[0].changeImg('folder/folder.png')
            }
        }
        return folder
    }
}
var myFile = {
    createNew:function(x = 0,y = 0,fname = '',src='folder/undefind_file.png'){
        var file = Folder.createNew(x,y,fname,src)
        file.x = x + 4
        file.y = y + 4
        file.width = 60
        file.height = 82
        file.state = 'unfocus'
        file.type = 'file'
        file.setPosition = function(x,y){
            file.picX = x
            file.picY = y
            file.x = x + 4 //物体位置
            file.y = y + 4
            file.getFolderAn().setPosition(x,y)
        }
        file.putOn = function(){
            var folderAn = file.getFolderAn()
            file.changeImg()
            DrawBoard.add(folderAn)
            DrawBoard.add(Text.createNew(file.getName(), folderAn.x, folderAn.y+120,'italic small-caps bold 12px arial'))
            Action.createNew('play',folderAn,0.1)
        }
        file.changeImg = function(mode = ''){
            if(mode == ''){
                mode = file.state
            }
            if(mode == 'focus'){
                file.getFolderAn().getSpiritArr()[0].changeImg('folder/undefind_file_focus.png')
            }
            if(mode == 'unfocus'){
                file.getFolderAn().getSpiritArr()[0].changeImg('folder/undefind_file.png')
            }
        }
        return file
    }
}





var DrawBoard = {
    spiritArr:[], //spirit数组
    ctx:null,
    width:0,
    height:0,
    init:function(canvasId, width=0, height=0){ 
        var c = document.getElementById(canvasId)
        this.ctx = c.getContext("2d")
        if(width == 0 || height == 0){
            c.width = window.screen.width
            c.height = window.screen.height
        }
        else{
            c.width = width
            c.height = height
        }
        this.width = c.width
        this.height = c.height
    },
    add:function(spirit){
        this.spiritArr.push(spirit)
    },
    clear:function(){ //清空画板
        this.spiritArr = []
    },
    drawSpirit:function(spirit){
        this.ctx.drawImage(spirit.img, spirit.sx, spirit.sy, spirit.swidth, 
            spirit.sheight, spirit.x, spirit.y, spirit.width, spirit.height)
    },
    drawText:function(text){ //text对象，不是字符串
        this.ctx.font = text.font
        this.ctx.fillText(text.message,text.x,text.y)
    },
    draw:function(){
        this.ctx.clearRect(0, 0, this.width, this.height)   
        this.spiritArr.forEach(spirit => {
            spirit.putOn()
        });
    }
}

var myEventListener = {
   
    init:function(canvasId){
        myEventListener.arr = []  //[[spirit,function,eventType]]
        document.oncontextmenu = function(e){ //去掉默认右击菜单
            e.preventDefault();
        };
        document.getElementById(canvasId).addEventListener('dblclick',myEventListener.handle)
        //document.getElementById(canvasId).addEventListener('click',myEventListener.handle)
        document.getElementById(canvasId).addEventListener('mousedown',myEventListener.handle)
    },
    add:function(spirit,func,type = 'click'){
        myEventListener.arr.push([spirit,func,type])
    },
    handle:function(e){
        console.log(e.x,e.y,e.type)
        var isAtBlank = true
        if(myEventListener.arr.length > 0){
            myEventListener.arr.forEach(elem => {
                var eType = e.type
                if(eType == 'mousedown' &&e.button == '0'){
                    eType = 'click'
                }
                if(eType == 'mousedown' &&e.button == '2'){
                    eType = 'rclick'
                }
                if(elem[2] == eType){
                    if(e.x > elem[0].x && e.x < (elem[0].x + elem[0].width)){
                        if(e.y >= elem[0].y && e.y <= elem[0].y + elem[0].height){
                            elem[1]() 
                            isAtBlank = false
                        }
                    }
                }
            });
        }
        if(isAtBlank){
            alert('im blank')
        }
    }
}

var Spirit = {
    createNewSplit:function(src='', x=0, y=0, scale=1, sx=0, sy=0, swidth=0, sheight=0){
        var spirit = {
        }
        var oImg= new Image();
        oImg.src = 'src/img/'+src;
        spirit.img = oImg; //src 为图片  名字.后缀
        spirit.x = x
        spirit.y = y
        spirit.sx = sx
        spirit.sy = sy
        spirit.swidth = swidth
        spirit.sheight = sheight
        spirit.scale = scale //缩放比例
        spirit.width = spirit.swidth*scale //精灵大小：宽
        spirit.height = spirit.sheight*scale //精灵大小：长
        spirit.mode = 's' //s = split 剪切下来的精灵
        spirit.putOn = function(){  //把精灵放进画板
            DrawBoard.drawSpirit(spirit)
        }
        spirit.changeImg = function(src){
            oImg= new Image();
            oImg.src = 'src/img/'+src;
            spirit.img = oImg
        }
        return spirit
    },
}

var Text = {
    createNew:function(tmessage,tx,ty,tfont = '10px sans-serif'){
        var text = {}
        text.x = tx
        text.y = ty
        text.font = tfont
        text.message = tmessage
        text.putOn = function(){
            DrawBoard.drawText(text)
        }
        return text
    }
} 

var Animation = {
    createNew:function(spititArr, delay = 1, x = null, y = null){
        var index = 0
        var an = {}
        var arr = spititArr
        var anDelayTime = delay //整个动画运行时间(s)
        var actionArr = [] //动作运行列表[action]
        var runFrame = 0  //已经运行的帧数
        var visible = false //默认可视(true)  不可视 (false)
        an.x = x
        an.y = y
        an.width = arr[0].width
        an.height = arr[0].height
        if(x == null){
            an.x = spititArr[0].x
            an.y = spititArr[0].y
        }
        an.getSpiritArr = function(){
            return arr
        }
        an.setPosition = function(x,y){
            an.x = x
            an.y = y
        }
        an.nextFrame = function(){ //根据action设置该an的下一帧
            runFrame++
            var nextIndex = parseInt(runFrame/parseInt(Engine.fps*anDelayTime/arr.length))
            if(nextIndex == arr.length){ //动画播到最后一个，重头开始
                nextIndex = 0
                runFrame = 0
            }
            
            if(actionArr.length > 0){ //action动作存在
               
                var act = actionArr[0]
                var next = act.getNext()
                //console.log(next)
                if(next == null){
                    actionArr.splice(0,1)
                    an.nextFrame()
                }
                else{
                    
                    if(next.mode == 'move'){
                        
                        visible = true
                        arr[nextIndex].x = an.x + next.x
                        arr[nextIndex].y = an.y + next.y
                        an.x = arr[nextIndex].x
                        an.y = arr[nextIndex].y
                        index = nextIndex
                    }
                    if(next.mode == 'pause'){
                        index = index
                        visible = true
                    }
                    if(next.mode == 'disappear'){
                        visible = false
                    }
                    if(next.mode == 'play'){
                        index = nextIndex
                        visible = true
                    }
                }
            }
            else{
                index = index
            }
        }
        //动画运行多少时间
        an.delay = function(delayTime){
            anDelayTime = delayTime
        }
        //添加动作
        an.addAction = function(action){
           actionArr.push(action)
        }
        an.putOn = function(){
            arr[index].x = an.x
            arr[index].y = an.y
            if(visible == true){
                DrawBoard.drawSpirit(arr[index])  
            }
            an.nextFrame()
            
        }
        return an
    }
}

var Action = {
    createNew:function(mode='', aspirit=null, delay=1, x=0, y=0){
        var action = {}
        var ax = x  //目标地点
        var ay = y
        if(mode == 'moveBy'){ //转相对移动为绝对移动
            ax = x + aspirit.x
            ay = y + aspirit.y
        }
        var delayTime = delay
        var amode = mode //行为模式 move pause
        var spirit = aspirit
        var moveByX = parseInt((ax-spirit.x)/(delayTime*Engine.fps))
        var moveByY = parseInt((ay-spirit.y)/(delayTime*Engine.fps))
        var frames = 0 //已经运行的帧数
        
        //获得行为下一步数据return {mode:modename,......}
        action.getNext = function(){
            if(amode == 'moveTo' || amode == 'moveBy'){ //移动到某个点，绝对移动
                if(frames >= delayTime*Engine.fps){
                    frames = 0
                    return null
                }
                else{
                    frames++
                    return {'mode':'move', 'x':moveByX,
                            'y':moveByY,'frames':frames}
                }
            }
            if(amode == 'pause' || amode == 'disappear' || amode == 'play'){ //暂停
                if(frames >= delayTime*Engine.fps){
                    frames = 0
                    return null
                }
                else{
                    frames++
                    return {'mode':amode,'frames':frames}
                }
            }
        }
        spirit.addAction(action)
        return action
    }
}

var Engine = {
    plan:[],
    fps:30,
    intvalId:0,
    canvasId:'',
    start:function(canvasId, fps = 30,width,height){
        DrawBoard.init(canvasId,width,height)
        myEventListener.init(canvasId)
        this.canvasId = canvasId
        this.fps = fps
        this.intvalId = setInterval(function(){
            DrawBoard.draw()
        },parseInt(1000/fps))
    },
    stop:function(){
        clearInterval(this.intvalId)
    },
    doContinue:function(){
        this.intvalId = setInterval(function(){
            DrawBoard.draw()
        },parseInt(1000/fps))
    }    
}
